import dotenv from 'dotenv';
dotenv.config();
// 改用官方 'openai' 套件
import OpenAI from 'openai';

const endpoint = process.env.AZURE_OPENAI_ENDPOINT;
const azureApiKey = process.env.AZURE_OPENAI_KEY;
const deploymentName = process.env.AZURE_OPENAI_DEPLOYMENT_NAME; // 請確保這是您的部署名稱

if (!endpoint || !azureApiKey || !deploymentName) {
  console.error("請確認 .env 檔案中已設定 AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_KEY, 和 AZURE_OPENAI_DEPLOYMENT_NAME");
  process.exit(1);
}

// 為 Azure 初始化 OpenAI client
// 注意：您可能需要根據您的 Azure OpenAI 設定調整 api-version
const client = new OpenAI({
  apiKey: azureApiKey,
  baseURL: `${endpoint}openai/deployments/${deploymentName}`,
  defaultQuery: { 'api-version': '2023-05-15' }, // 或其他您使用的 API 版本
  defaultHeaders: { 'api-key': azureApiKey },
});


async function callAzureOpenAI(prompt) {
  console.log(`正在傳送 prompt 到 Azure OpenAI (${deploymentName})...`);
  try {
    // 使用 client.chat.completions.create 進行流式傳輸
    const stream = await client.chat.completions.create({
        model: deploymentName, // 標準 client 需要 model 參數
        messages: [
            { role: "system", content: "You are a helpful assistant." },
            { role: "user", content: prompt },
        ],
        stream: true,
    });

    let fullResponse = "";
    console.log("\nAzure OpenAI 回應:");
    for await (const chunk of stream) {
        const delta = chunk.choices[0]?.delta?.content || "";
        process.stdout.write(delta); // 流式輸出
        fullResponse += delta;
    }
    console.log("\n--- 回應結束 ---");
    return fullResponse;
  } catch (error) {
    // 提供更詳細的錯誤輸出
    console.error("\n呼叫 Azure OpenAI API 時發生錯誤:");
    if (error instanceof OpenAI.APIError) {
      console.error(`  狀態碼: ${error.status}`);
      console.error(`  回應標頭: ${JSON.stringify(error.headers)}`);
      console.error(`  錯誤回應: ${JSON.stringify(error.error)}`);
    } else {
      console.error(error);
    }
    return null;
  }
}

// --- 主程式執行 ---
async function main() {
  // 從命令列參數獲取 prompt，如果沒有提供，則使用英文預設值
  const userPrompt = process.argv[2] || "介紹你自己"; 

  if (!userPrompt) {
    console.log("用法: node callAzureOpenAI.js \"您的 prompt\"");
    return;
  }
  console.log('>>>>>', userPrompt);
  await callAzureOpenAI(userPrompt);
}

main(); 