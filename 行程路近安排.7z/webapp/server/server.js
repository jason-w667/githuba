import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import cors from 'cors';
import http from 'http';
import { WebSocketServer } from 'ws';
import { spawn } from 'child_process';
import dotenv from 'dotenv';

// 載入環境變數
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = process.env.PORT || 3000;

// 創建 HTTP 服務器
const server = http.createServer(app);
// 設置 WebSocket 服務器
const wss = new WebSocketServer({ server });
// Serve static files from public directory
app.use(express.static(path.join(__dirname, '../public')));

// 新增 JSON body 解析中介層
app.use(express.json());

// 啟用 CORS: 允許所有來源
app.use(cors());

// WebSocket 連接處理
wss.on('connection', (ws) => {
    console.log('WebSocket 客戶端已連接');
    
    ws.on('message', (message) => {
        let data;
        try {
            data = JSON.parse(message);
        } catch (err) {
            ws.send(JSON.stringify({ type: 'error', message: '無效的 JSON' }));
            return;
        }
        
        const { prompt } = data;
        if (!prompt) {
            ws.send(JSON.stringify({ type: 'error', message: '未提供 prompt' }));
            return;
        }

        // 告知前端開始接收串流
        ws.send(JSON.stringify({ type: 'start' }));

        // 呼叫 callAzureOpenAI.js 並傳入 prompt
        const scriptPath = path.join(__dirname, '../callAzureOpenAI.js');
        const child = spawn('node', [scriptPath, prompt]);

        // 接收子程序 stdout 串流內容
        child.stdout.on('data', (chunk) => {
            const text = chunk.toString();
            ws.send(JSON.stringify({ type: 'chunk', delta: text }));
        });

        child.stderr.on('data', (chunk) => {
            console.error(`子進程錯誤: ${chunk.toString()}`);
            ws.send(JSON.stringify({ type: 'error', message: '處理請求時發生錯誤' }));
        });

        child.on('close', (code) => {
            ws.send(JSON.stringify({ type: 'end' }));
            console.log(`子進程結束，退出碼: ${code}`);
        });
    });

    ws.on('close', () => {
        console.log('WebSocket 客戶端已斷開連接');
    });
});

// 路線規劃與天氣查詢 API
app.post('/route-plan', async (req, res) => {
  const { origin, destination, travelMode, userWeight } = req.body;
  const AZURE_MAPS_KEY = process.env.AZURE_MAPS_KEY;
  if (!origin || !destination) {
    return res.json({ error: '請提供起點與終點' });
  }
  if (!AZURE_MAPS_KEY) {
    return res.json({ error: '缺少 Azure Maps 金鑰' });
  }

  // 1. 解析地名為經緯度
  async function geocode(query) {
    console.log(`🔍 開始解析地名: "${query}"`);
    
    // 已知地名對照表（優先使用）
    const knownLocations = {
      '台北車站': { lat: 25.0478, lon: 121.5174 },
      '台北火車站': { lat: 25.0478, lon: 121.5174 },
      '台中車站': { lat: 24.1369, lon: 120.6850 },
      '台中火車站': { lat: 24.1369, lon: 120.6850 },
      '高雄車站': { lat: 22.6394, lon: 120.3020 },
      '高雄火車站': { lat: 22.6394, lon: 120.3020 },
      '台南車站': { lat: 22.9971, lon: 120.2129 },
      '台南火車站': { lat: 22.9971, lon: 120.2129 },
      '台北101': { lat: 25.0330, lon: 121.5654 },
      '桃園車站': { lat: 24.9936, lon: 121.3010 },
      '新竹車站': { lat: 24.8138, lon: 120.9675 },
      '基隆車站': { lat: 25.1312, lon: 121.7444 },
      '花蓮車站': { lat: 23.9871, lon: 121.6011 },
      '台東車站': { lat: 22.7940, lon: 121.1454 },
      '宜蘭車站': { lat: 24.7021, lon: 121.7377 },
      '屏東車站': { lat: 22.5510, lon: 120.5488 },
      '嘉義車站': { lat: 23.4801, lon: 120.4491 },
      '彰化車站': { lat: 24.0809, lon: 120.5381 },
      '苗栗車站': { lat: 24.5606, lon: 120.8214 },
      '雲林車站': { lat: 23.7092, lon: 120.4313 },
      '南投車站': { lat: 23.9609, lon: 120.6860 }
    };

    // 檢查是否為已知地名
    if (knownLocations[query]) {
      console.log(`✅ 使用已知地名: ${query} -> ${knownLocations[query].lat}, ${knownLocations[query].lon}`);
      return knownLocations[query];
    }

    // 多種搜尋策略
    const searchStrategies = [
      // 策略1: 原始查詢
      query,
      // 策略2: 加上 Taiwan
      query + ', Taiwan',
      // 策略3: 加上 Taipei
      query + ', Taipei',
      // 策略4: 加上 台灣
      query + ', 台灣',
      // 策略5: 英文地名對照
      getEnglishName(query),
      // 策略6: 簡化查詢
      query.trim().replace(/\s+/g, ' '),
      // 策略7: 加上完整地址
      query + ', Taiwan, Republic of China'
    ].filter(Boolean); // 過濾空值

    // 嘗試每種搜尋策略
    for (const strategy of searchStrategies) {
      try {
        console.log(`🔍 嘗試策略: "${strategy}"`);
        const url = `https://atlas.microsoft.com/search/address/json?api-version=1.0&subscription-key=${AZURE_MAPS_KEY}&query=${encodeURIComponent(strategy)}`;
        const resp = await fetch(url);
        const data = await resp.json();
        
        if (data.results && data.results.length > 0) {
          const result = data.results[0];
          const { position } = result;
          console.log(`✅ 搜尋成功: ${query} -> ${position.lat}, ${position.lon}`);
          console.log(`📍 解析地址: ${result.address.freeformAddress}`);
          return { lat: position.lat, lon: position.lon };
        }
      } catch (e) {
        console.error(`❌ 策略失敗: "${strategy}" - ${e.message}`);
      }
    }
    
    throw new Error(`無法找到地點：${query}。請嘗試使用經緯度座標或英文地名。`);
  }

  // 中文地名轉英文
  function getEnglishName(chineseName) {
    const nameMap = {
      '台北車站': 'Taipei Main Station',
      '台北火車站': 'Taipei Main Station',
      '台中車站': 'Taichung Station',
      '台中火車站': 'Taichung Station',
      '高雄車站': 'Kaohsiung Station',
      '高雄火車站': 'Kaohsiung Station',
      '台南車站': 'Tainan Station',
      '台南火車站': 'Tainan Station',
      '台北101': 'Taipei 101',
      '桃園車站': 'Taoyuan Station',
      '新竹車站': 'Hsinchu Station',
      '基隆車站': 'Keelung Station',
      '花蓮車站': 'Hualien Station',
      '台東車站': 'Taitung Station',
      '宜蘭車站': 'Yilan Station',
      '屏東車站': 'Pingtung Station',
      '嘉義車站': 'Chiayi Station',
      '彰化車站': 'Changhua Station',
      '苗栗車站': 'Miaoli Station',
      '雲林車站': 'Yunlin Station',
      '南投車站': 'Nantou Station'
    };
    
    return nameMap[chineseName] || null;
  }

  // 計算步行能量消耗
  function calculateWalkingEnergy(distanceKm, userWeight = 70) {
    // 步行能量消耗公式：每公里約消耗 60-80 卡路里（根據體重調整）
    const caloriesPerKm = 60 + (userWeight - 50) * 0.4; // 體重越重消耗越多
    const totalCalories = distanceKm * caloriesPerKm;
    
    // 轉換為其他單位
    const kj = totalCalories * 4.184; // 千焦耳
    const steps = Math.round(distanceKm * 1250); // 每公里約1250步
    
    return {
      calories: Math.round(totalCalories),
      kj: Math.round(kj),
      steps: steps,
      distanceKm: distanceKm
    };
  }

  // 計算每日步行能量消耗
  function calculateDailyWalkingEnergy(dailyDistanceKm, userWeight = 70) {
    const dailyEnergy = calculateWalkingEnergy(dailyDistanceKm, userWeight);
    
    // 健康建議：每日步行 10,000 步（約 8 公里）
    const recommendedSteps = 10000;
    const recommendedDistance = 8;
    const recommendedEnergy = calculateWalkingEnergy(recommendedDistance, userWeight);
    
    return {
      ...dailyEnergy,
      recommendedSteps,
      recommendedDistance,
      recommendedCalories: recommendedEnergy.calories,
      isHealthy: dailyDistanceKm >= recommendedDistance
    };
  }

  // 比較駕車與步行的個人化建議
  function compareTransportModes(distanceKm, travelTime, userWeight = 70) {
    const walkingEnergy = calculateWalkingEnergy(distanceKm, userWeight);
    const walkingTime = Math.round(distanceKm * 12); // 步行速度約 5km/h
    
    const comparison = {
      driving: {
        time: travelTime,
        energy: 0, // 駕車不消耗體力
        cost: Math.round(distanceKm * 2), // 油費估算
        carbon: Math.round(distanceKm * 0.2) // CO2排放估算
      },
      walking: {
        time: walkingTime,
        energy: walkingEnergy.calories,
        steps: walkingEnergy.steps,
        health: '有益健康',
        carbon: 0
      }
    };
    
    // 個人化建議
    let recommendation = '';
    if (distanceKm <= 2) {
      recommendation = '建議步行：距離短，有益健康';
    } else if (distanceKm <= 5) {
      recommendation = '可考慮步行：中等距離，消耗 ' + walkingEnergy.calories + ' 卡路里';
    } else {
      recommendation = '建議駕車：距離較長，步行耗時 ' + walkingTime + ' 分鐘';
    }
    
    return {
      ...comparison,
      recommendation,
      distanceKm
    };
  }

  try {
    // 支援經緯度直接輸入
    function parseLatLon(str) {
      const m = str.match(/^\s*(-?\d+\.?\d*)[,， ]+(-?\d+\.?\d*)\s*$/);
      if (m) return { lat: parseFloat(m[1]), lon: parseFloat(m[2]) };
      return null;
    }
    let origCoord = parseLatLon(origin) || await geocode(origin);
    let destCoord = parseLatLon(destination) || await geocode(destination);

    // Debug 輸出
    console.log(`📍 起點: ${origin} -> ${origCoord.lat}, ${origCoord.lon}`);
    console.log(`📍 終點: ${destination} -> ${destCoord.lat}, ${destCoord.lon}`);

    // 2. 查詢交通方式
    let modes = [];
    
    if (travelMode && travelMode !== 'auto') {
      // 使用者指定了交通方式
      const modeMap = {
        'car': { mode: 'car', label: '駕車' },
        'pedestrian': { mode: 'pedestrian', label: '步行' },
        'publicTransport': { mode: 'publicTransport', label: '大眾運輸' }
      };
      modes = [modeMap[travelMode]];
      console.log(`🎯 使用者選擇: ${modes[0].label}`);
    } else {
      // 自動判斷 - 查詢所有交通方式
      modes = [
        { mode: 'car', label: '駕車' },
        { mode: 'pedestrian', label: '步行' },
        { mode: 'publicTransport', label: '大眾運輸' }
      ];
      console.log(`🤖 自動判斷模式`);
    }
    
    let best = null;
    let foundModes = [];
    
    for (const m of modes) {
      try {
        console.log(`🚗 查詢交通方式: ${m.label}`);
        const url = `https://atlas.microsoft.com/route/directions/json?api-version=1.0&subscription-key=${AZURE_MAPS_KEY}&query=${origCoord.lat},${origCoord.lon}:${destCoord.lat},${destCoord.lon}&travelMode=${m.mode}`;
        const resp = await fetch(url);
        const data = await resp.json();
        
        if (data.routes && data.routes.length > 0) {
          const summary = data.routes[0].summary;
          foundModes.push(m.label);
          console.log(`✅ ${m.label} 路線找到: ${summary.lengthInMeters}m, ${summary.travelTimeInSeconds}s`);
          
          if (!best || summary.travelTimeInSeconds < best.summary.travelTimeInSeconds) {
            best = { ...m, summary };
            console.log(`🏆 目前最佳: ${best.label}`);
          }
        } else {
          console.log(`❌ ${m.label} 無路線`);
        }
      } catch (e) {
        console.error(`❌ ${m.label} 查詢失敗:`, e.message);
      }
    }
    
    if (!best) {
      const modeText = travelMode && travelMode !== 'auto' ? travelMode : '所有交通方式';
      throw new Error(`無法找到 ${modeText} 的路線。請嘗試其他交通方式或檢查起點終點。`);
    }
    
    console.log(`🎯 最終選擇: ${best.label}`);
    const duration = Math.round(best.summary.travelTimeInSeconds / 60) + ' 分鐘';
    const distanceKm = best.summary.lengthInMeters / 1000;
    const distance = distanceKm.toFixed(1) + ' 公里';
    console.log(`📏 距離: ${distance} (${distanceKm}km), ⏱️ 時間: ${duration}`);

    // 計算步行能量消耗（如果距離在10公里內）
    let energyInfo = null;
    let comparisonInfo = null;
    
    if (distanceKm <= 10) {
      const weight = userWeight || 70; // 使用傳入的體重或預設值
      energyInfo = calculateWalkingEnergy(distanceKm, weight);
      comparisonInfo = compareTransportModes(distanceKm, duration, weight);
      
      console.log(`🔥 步行能量消耗: ${energyInfo.calories} 卡路里`);
      console.log(`👟 步行步數: ${energyInfo.steps} 步`);
      console.log(`💡 個人化建議: ${comparisonInfo.recommendation}`);
      console.log(`🚗 駕車時間: ${comparisonInfo.driving.time} 分鐘`);
      console.log(`🚶 步行時間: ${comparisonInfo.walking.time} 分鐘`);
    } else {
      console.log(`📏 距離超過10公里 (${distanceKm}km)，不顯示個人化建議`);
    }

    // 3. 查詢天氣
    const weatherUrl = `https://atlas.microsoft.com/weather/currentConditions/json?api-version=1.1&subscription-key=${AZURE_MAPS_KEY}&query=${origCoord.lat},${origCoord.lon}`;
    const weatherResp = await fetch(weatherUrl);
    const weatherData = await weatherResp.json();
    let weatherDesc = '未知';
    let temp = '';
    if (weatherData.results && weatherData.results[0]) {
      weatherDesc = weatherData.results[0].phrase;
      temp = Math.round(weatherData.results[0].temperature.value) + '°C';
    }

    // 4. 回傳整合資訊
    const result = {
      交通方式: best.label,
      預估時間: duration,
      距離: distance,
      起點天氣: `${weatherDesc}，${temp}`
    };

    // Debug log
    console.log('distanceKm:', distanceKm);
    console.log('energyInfo:', energyInfo);
    console.log('comparisonInfo:', comparisonInfo);

    // 如果距離在10公里內，加入駕車/步行選項
    if (distanceKm <= 10 && energyInfo && comparisonInfo) {
      result.選項 = {
        駕車: {
          時間: `${comparisonInfo.driving.time} 分鐘`,
          成本: `約 ${comparisonInfo.driving.cost} 元油費`
        },
        步行: {
          時間: `${comparisonInfo.walking.time} 分鐘`,
          步數: `${energyInfo.steps} 步`,
          能量: `${energyInfo.calories} 卡路里`,
          健康: comparisonInfo.walking.health
        }
      };
      console.log('已進入選項回傳區塊，result.選項:', result.選項);
    } else {
      console.log('未進入選項回傳區塊，條件:', distanceKm, energyInfo, comparisonInfo);
    }

    console.log('回傳結果:', result);
    res.json(result);
  } catch (e) {
    res.json({ error: e.message });
  }
});

// 提供 azure_api.md 給前端讀取
app.get('/azure_api.md', (req, res) => {
  res.sendFile(path.resolve(__dirname, '../azure_api.md'));
});

// 使用 server 而不是 app 來監聽
server.listen(port, () => {
    console.log(`伺服器運行於 http://localhost:${port}`);
}); 